#import "CPTTestCase.h"

@interface CPTTextStyleTests : CPTTestCase {
}

@end
