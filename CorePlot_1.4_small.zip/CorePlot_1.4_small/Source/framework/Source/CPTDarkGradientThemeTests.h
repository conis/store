#import "CPTTestCase.h"

@interface CPTDarkGradientThemeTests : CPTTestCase {
}

@end
