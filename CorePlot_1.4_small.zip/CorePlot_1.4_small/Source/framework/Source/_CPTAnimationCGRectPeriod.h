#import "CPTAnimationPeriod.h"

@interface _CPTAnimationCGRectPeriod : CPTAnimationPeriod {
}

@end
