#import "CPTTestCase.h"

@interface CPTMutableNumericDataTests : CPTTestCase {
}

@end
