#import "CPTLayer.h"

@interface CPTMaskLayer : CPTLayer  {
}

@end
