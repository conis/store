#import "CPTTestCase.h"

@interface CPTAxisLabelTests : CPTTestCase {
}

@end
