#import "CPTAnimationPeriod.h"

@interface _CPTAnimationNSDecimalPeriod : CPTAnimationPeriod {
}

@end
