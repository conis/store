#import "CPTTestCase.h"

@interface CPTNumericDataTypeConversionPerformanceTests : CPTTestCase {
}

@end
