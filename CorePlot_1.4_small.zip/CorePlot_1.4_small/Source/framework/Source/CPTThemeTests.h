#import "CPTTestCase.h"

@interface CPTThemeTests : CPTTestCase {
}

@end
