#import "CPTAnimationPeriod.h"

@interface _CPTAnimationCGSizePeriod : CPTAnimationPeriod {
}

@end
