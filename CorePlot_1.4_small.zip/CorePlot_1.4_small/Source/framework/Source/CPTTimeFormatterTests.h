#import "CPTTestCase.h"

@interface CPTTimeFormatterTests : CPTTestCase {
}

@end
