@interface CPTDecimalNumberValueTransformer : NSValueTransformer {
}

@end
