#import <SenTestingKit/SenTestingKit.h>

@interface CPTTestCase : SenTestCase {
}

@end
