//
//  PlotHostView.h
//  Plot Gallery
//
//  Created by Jeff Buck on 9/4/10.
//  Copyright 2010 Jeff Buck. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlotHostView : UIView
{
}

@end
