//
//  PlotSpaceDemo.h
//  Plot Gallery
//

#import "PlotItem.h"

@interface PlotSpaceDemo : PlotItem
{
}

@end
