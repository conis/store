//
//  LineCapDemo.h
//  Plot Gallery
//

#import "PlotItem.h"

@interface LineCapDemo : PlotItem
{
}

@end
