//
//  LabelingPolicyDemo.h
//  Plot Gallery
//

#import "PlotItem.h"

@interface LabelingPolicyDemo : PlotItem
{
}

@end
