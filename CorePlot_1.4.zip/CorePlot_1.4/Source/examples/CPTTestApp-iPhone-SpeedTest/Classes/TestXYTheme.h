//
//  TestXYTheme.h
//  CPTTestApp-iPhone
//
//  Created by Joan on 03/06/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "CorePlot-CocoaTouch.h"

@interface TestXYTheme : CPTTheme
{
}

@end
