#import <Foundation/Foundation.h>

@interface NSDictionary(APFinancalData)

+(id)dictionaryWithCSVLine:(NSString *)csvLine;

@end
