#import <Cocoa/Cocoa.h>
#import <CorePlot/CorePlot.h>

@interface AxisDemoController : NSObject {
    IBOutlet CPTGraphHostingView *hostView;
}

@end
