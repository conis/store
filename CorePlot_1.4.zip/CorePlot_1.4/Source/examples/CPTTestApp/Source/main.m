//
//  main.m
//  CPTTestApp
//
//  Created by Dirkjan Krijnders on 2/2/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
