#import <UIKit/UIKit.h>

@interface UINavigationController(LegacyRotation)

@end
