#import <UIKit/UIKit.h>

@interface UIViewController(LegacyRotation)

@end
