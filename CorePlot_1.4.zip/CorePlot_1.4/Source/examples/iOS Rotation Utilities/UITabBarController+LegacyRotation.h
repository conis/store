#import <UIKit/UIKit.h>

@interface UITabBarController(LegacyRotation)

@end
