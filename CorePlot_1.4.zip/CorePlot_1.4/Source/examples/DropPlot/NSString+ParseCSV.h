#import <Cocoa/Cocoa.h>

@interface NSString(ParseCSV)

-(NSArray *)arrayByParsingCSVLine;

@end
