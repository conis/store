//
//  main.m
//  DropPlot
//
//  Created by Brad Larson on 6/9/2009.
//  Copyright SonoPlot, Inc. 2009 . All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
