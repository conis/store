//
//  FlipsideView.m
//  AAPLot
//
//  Created by Jonathan Saggau on 6/9/09.
//  Copyright Sounds Broken inc. 2009. All rights reserved.
//

#import "FlipsideView.h"

@implementation FlipsideView

-(id)initWithFrame:(CGRect)frame
{
    if ( self = [super initWithFrame:frame] ) {
        // Initialization code
    }
    return self;
}

-(void)drawRect:(CGRect)rect
{
    // Drawing code
}

-(void)dealloc
{
    [super dealloc];
}

@end
