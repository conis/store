#import <Foundation/Foundation.h>

@interface NSDateFormatter(APExtensions)

+(NSDateFormatter *)csvDateFormatter;

@end
