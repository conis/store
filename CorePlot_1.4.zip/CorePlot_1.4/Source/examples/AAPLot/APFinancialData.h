#import <Foundation/Foundation.h>

@interface NSDictionary(APFinancialData)

+(id)dictionaryWithCSVLine:(NSString *)csvLine;

@end
