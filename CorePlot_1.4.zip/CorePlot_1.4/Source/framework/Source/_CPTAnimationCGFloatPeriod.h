#import "CPTAnimationPeriod.h"

@interface _CPTAnimationCGFloatPeriod : CPTAnimationPeriod

@end
