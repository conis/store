#import "CPTTestCase.h"

@interface CPTNumericDataTests : CPTTestCase {
}

@end
