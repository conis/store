#import "CPTAnimationPeriod.h"

@interface _CPTAnimationPlotRangePeriod : CPTAnimationPeriod {
}

@end
