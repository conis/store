#import "CPTTestCase.h"

@interface CPTColorSpaceTests : CPTTestCase {
}

@end
