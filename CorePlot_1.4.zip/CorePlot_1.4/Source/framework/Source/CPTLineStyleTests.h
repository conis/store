#import "CPTTestCase.h"

@interface CPTLineStyleTests : CPTTestCase {
}

@end
