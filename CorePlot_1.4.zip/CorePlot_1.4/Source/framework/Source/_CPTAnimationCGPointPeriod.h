#import "CPTAnimationPeriod.h"

@interface _CPTAnimationCGPointPeriod : CPTAnimationPeriod {
}

@end
