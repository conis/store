#import "CPTLayer.h"

@interface CPTAxisLabelGroup : CPTLayer {
}

@end
